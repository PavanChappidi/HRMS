package bin;
import java.io.IOException;
class IDGenerator{
	static CSVOperation fileRef = new CSVOperation();
	static String defaultInEmpStr = "ISINEMP";
	static String defaultUSEmpStr = "ISUSEMP";
	static String EMPID = "";
	static String prevEmp = "";
	static String prevCon = "";
	static String defaultInConStr = "ISINCON";
	static String defaultUSConStr = "ISUSCON";
	static String key1 = "EMP";
	static String key2 = "CON";
	public static String generateEmpID(String country) throws IOException{

		if(fileRef.getPreviousEmpID(key1).equals("empty")){
			if(country.equalsIgnoreCase("india")){
				EMPID = defaultInEmpStr + Integer.toString(1001);
			}else{
				EMPID = defaultUSEmpStr + Integer.toString(1001);
			}
		}else{
			prevEmp = fileRef.getPreviousEmpID(key1).substring(7);
			int seriesCount = Integer.parseInt(prevEmp);
			seriesCount++;
			EMPID = (country.equalsIgnoreCase("india"))? defaultInEmpStr + Integer.toString(seriesCount) : defaultUSEmpStr + Integer.toString(seriesCount) ;
			
				
				
		}		
		return EMPID;
	}

	public static String generateConID(String country) throws IOException {
	
		if(fileRef.getPreviousEmpID(key2).equals("empty")){
			if(country.equalsIgnoreCase("india")){
				EMPID = defaultInConStr + Integer.toString(5001);
			}else{
				EMPID = defaultUSConStr + Integer.toString(5001);
			}
		}else{
			prevCon = fileRef.getPreviousEmpID(key2).substring(7);
			int seriesCount = Integer.parseInt(prevCon);
			seriesCount++;
			EMPID = (country.equalsIgnoreCase("india"))? defaultInConStr + Integer.toString(seriesCount) : defaultUSConStr + Integer.toString(seriesCount) ;
			
				
				
		}		
		return EMPID;
	}

}

					