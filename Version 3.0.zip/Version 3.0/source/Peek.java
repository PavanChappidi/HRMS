package bin;
import java.util.HashMap;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

class Peek{

	BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
	CSVOperation peekClass = new CSVOperation();
	public void menu() throws IOException{
		int choice = 2;
		System.out.print("\n\n\t\t\t\t Search filters\n");
		System.out.print("\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		System.out.print("\t\t\t\t 1.Search based on manager \n\t\t\t\t 2.Search based on Employee ID \t\t\t\t  \n \t\t\t\t 3.Search based on type of Resource \n \t\t\t\t 4.Search based on country\n\n");
		System.out.print("\t\t\t\t Enter any option [eg:2] : ");
		choice = Integer.parseInt(consoleReader.readLine());
		switch(choice){

			case 1 :	try{
					System.out.print("\n Enter name of the manager : ");
					String name = consoleReader.readLine();
					HashMap<Integer,String> employeesUnderManager = peekClass.getRequestedQuery(name, 7);
					if(employeesUnderManager.size() != 0){
					for(int j = 0 ; j < employeesUnderManager.size() ; j++ ){
						printContentInMap(peekClass.getSingleRecord(employeesUnderManager.get(j)));
					}
					break;
					}else{
						System.out.print("no such record found");
					}
					}catch(Exception e){
						System.out.print("no employees under the requested manager");
						break;
					}

			case 2 :	
					System.out.print("\n Enter Employee ID : ");
					String empID = consoleReader.readLine();
					HashMap<Integer,String> allDetails = peekClass.getRequestedQuery(empID,0);
					try{
					if(allDetails.get(0).equalsIgnoreCase(empID)){
						
						printContentInMap(peekClass.getSingleRecord(allDetails.get(0)));
					}
					break;				
					}catch(Exception e){

						System.out.print("No such record found");
						break;
					}

			case 3:		System.out.print("\n Enter type Of Resource(eg: employee or contractor) : ");
					String type = consoleReader.readLine();
					type = type.substring(0,3).toUpperCase();
					HashMap<Integer,String> typeDetails = peekClass.getRequestedQuery(type,0);
					for(int j = 0 ; j < typeDetails.size() ; j++ ){
						printContentInMap(peekClass.getSingleRecord(typeDetails.get(j)));
					}
					break;

			case 4 :	System.out.print("\n Enter name of the country : "); 
					String country = consoleReader.readLine().toUpperCase();
					HashMap<Integer, String> countryBased = peekClass.getRequestedQuery(country, 11);
					for(int j = 0 ; j < countryBased.size() ; j++ ){
						printContentInMap(peekClass.getSingleRecord(countryBased.get(j)));
					}
					break;

			default:	System.out.print("\nPlease enter correct option and try again\n\n");
					break;
					
		}
	}

	public static void printContentInMap(HashMap in){
		try{
		String[] columnHeader = {"Employee/Contractor ID: ", "Name of the Employee : ","Department : " ,"Designation : ","CTC: ","Date of Joining: ","Date of End: ","Name of the Manager : ", "Address : ", "Contact :  ","Email ID: ", "Country : ", "Status : "};
		for(int i = 0  ;i< in.size() ; i ++){
		
			System.out.print("\n" + columnHeader[i]+in.get(i));
		}
		System.out.print("\n");
		}catch(Exception e){
			
		}
	}

	public static String getContentInMap(HashMap<Integer,String> in){
	
		String toMail = "";
		String[] columnHeader = {"Employee/Contractor ID: ", "Name of the Employee : ","Department : " ,"Designation : ","CTC: ","Date of Joining: ","Date of End: ","Name of the Manager : ", "Address : ", "Contact :  ","Email ID: ", "Country : ", "Status : "};
		for(int i = 0  ;i< in.size() ; i ++){
			if(i == 4 || i== 5 || i==6 || i==7 || i==8 || i==11 || i == 12){
				continue;
			}
			toMail = toMail + columnHeader[i]+in.get(i)+"\n";
		}
		return toMail;
	}
}

					
					

				
		
		

		

				