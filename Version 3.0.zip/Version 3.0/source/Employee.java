package bin;
abstract class Employee implements Resource{

	abstract public String getEmpID() throws Exception;
	abstract public String getName();
	abstract public String getCTC();
	abstract public String getManager();
	abstract public String getAddress();
	abstract public String getContact();
	abstract public String getStatus();
	abstract public String getCountry();
	abstract public String getAll();
	abstract public void setEmpID(String id);
	abstract public void setName(String name);
	abstract public void setCTC(String ctc);
	abstract public void setManager(String manager);
	abstract public void setAddr(String address);
	abstract public void setContact(String contact);
	abstract public void setDOJ(String date);
	abstract public void setDOE(String date);
	abstract public void setDepartment(String dept);
	abstract public void setDesignation(String desgn);
	abstract public void setEmail(String mail);

}