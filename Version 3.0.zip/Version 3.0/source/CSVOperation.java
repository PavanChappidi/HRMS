package bin;

import java.io.File;
import java.util.HashMap;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.StringReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
class CSVOperation{

	
	String temp="";
	String readTemp = "";
	static byte[] tt;
	static SecuringData cd = new SecuringData();
	static File database = new File("enhdb.csv");
	
	public void addFile(HashMap<Integer, String> readData) throws Exception {
		
			FileInputStream encryptedReader = new FileInputStream(database);
			for(int i = 0 ; i< readData.size() ; i++ ){
					
				if(i < readData.size()-1){
					temp = temp + readData.get(i) + ",";
				}else{
			
					temp = temp+ readData.get(i);
				}
			}
			temp = temp + "\n";
			byte[] encData = new byte[(int)database.length()];
			encryptedReader.read(encData);
			try{
				byte[] decStream = cd.decryptData(encData);
				String decrypt = new String(decStream);
				decrypt = decrypt+temp;
				temp="";
				writeEncrypted(decrypt);
				
			}catch(Exception e){
				System.out.print("\n database is clean, method has fallen into exception");
				String decTemp = "";
				decTemp = decTemp+temp;
				System.out.print("\n3\n"+decTemp+"\n4\n");
				temp="";
				writeEncrypted(decTemp);

			}
				
					
	}


	public String getPreviousEmpID(String key) throws IOException{ //this method should be called when there is data in data base

		int i = 0;
		String EmpId = "empty";
		String decStr = decryptStream();
		BufferedReader csvReader = new BufferedReader(new StringReader(decStr));
		while((readTemp = csvReader.readLine()) != null){
					
			String[] allData = readTemp.split(",");
				try{
					if(allData[0].substring(4,7).equalsIgnoreCase(key)){

						EmpId = allData[0];
					}
				}catch(Exception IndexOutOfBoundException){
								
				}
			}
		
		return EmpId;					
	}

	public  HashMap<Integer, String> getSingleRecord(String EmpID) throws IOException{
	
		String decStr = decryptStream();
		BufferedReader csvReader = new BufferedReader(new StringReader(decStr));
		int i = 0;
		HashMap<Integer, String> singleRecord = new HashMap<Integer, String>();
		while((readTemp = csvReader.readLine()) != null){

			String[] allData = readTemp.split(",");
			try{
				if(allData[0].equalsIgnoreCase(EmpID)){
			
					for(String s : allData){

						singleRecord.put(i++, s);
					}
				}
			}catch(Exception IndexOutOfBoundException){
					System.out.print("\nexception in CSVOperation at SingleRecordmethod");
			}
		}
		return singleRecord;

	}

	
	public HashMap<Integer,String> getRequestedQuery(String name, int i) throws IOException{
		
		String decStr = decryptStream();
		BufferedReader csvReader = new BufferedReader(new StringReader(decStr));
		int key = 0;		
		HashMap<Integer, String> employeesType = new HashMap<Integer, String>();
		while((readTemp = csvReader.readLine()) != null){

			String[] allData = readTemp.split(",");
			try{
				if(allData[i].equalsIgnoreCase(name) || allData[i].contains(name)){
					employeesType.put(key++, allData[0]);
				}
			}catch(Exception IndexOutOfBoundException){
					System.out.print("\nPlease enter valid credentials");
			}
		}

		return employeesType;
	}		
	
	public void modifyQuery(String EmpID, String newEntry, int loc) throws Exception{

			StringModifier.modifyStr(EmpID,newEntry,loc);	
			
	}

	public boolean validateEmpID(String EmpID) throws Exception{
		boolean verify = false;
		String dec = decryptStream();
		BufferedReader csvReader = new BufferedReader(new StringReader(dec));
		while((readTemp = csvReader.readLine()) != null){
					
			String[] allData = readTemp.split(",");
			
			if(allData[0].equalsIgnoreCase(EmpID)){

				verify = true;
			}
				
		}

		return verify;
		

	}

	public static void writeEncrypted(String decTemp) throws Exception {

	FileOutputStream fos = new FileOutputStream(database);
	tt = cd.encryptData(decTemp.getBytes());
	fos.write(tt);
	fos.flush();
	fos.close();
	System.out.print("\n Data encrypted and uploaded to csv");

	}
	public static String decryptStream(){

		String allData="no entry sent";
		try{
			FileInputStream fis1 = new FileInputStream(database);
			byte[] decStr = new byte[(int) database.length()];
			fis1.read(decStr);
			allData = new String(cd.decryptData(decStr));
		}catch(Exception e){
			System.out.print("\n exception at decryptStream");
		}
		return allData;
	}

				
	
		

}