package bin;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.security.KeyStore;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.File;
public class SecuringData{

	static String userIn;
	static String filepath = ".\\cacerts";
	static char[] password = "changeit".toCharArray();
	static File file = new File(filepath);
	public static byte[] encryptData(byte[] userIn) throws Exception{
		Cipher algo = getCipher();
		SecretKey unique = loadKey();
		algo.init(Cipher.ENCRYPT_MODE,unique);
		byte[] encStream = algo.doFinal(userIn);
		 return encStream;
		
	}
	public static byte[] decryptData(byte[] encString) throws Exception{
		
		Cipher algo = getCipher();
		SecretKey unique = loadKey();
		algo.init(Cipher.DECRYPT_MODE,unique);
		byte[] decStream = algo.doFinal(encString);
		return decStream;
	}
	
	public static void storeKey(SecretKey unique) throws Exception{
	
		
		FileInputStream input = new FileInputStream(file); 
		KeyStore keystore = KeyStore.getInstance("JCEKS"); 
		if(!file.exists()){
			
			keystore.load(null,null);	
		}
		keystore.load(input,password);
		keystore.setKeyEntry("csvkey",unique,password,null);
		FileOutputStream writer = new FileOutputStream(filepath);
		keystore.store(writer,password);
	}

	public static SecretKey loadKey(){

		try{
			KeyStore keystore = KeyStore.getInstance("JCEKS");
			FileInputStream reader = new FileInputStream(file);
			keystore.load(reader, password);
			SecretKey key = (SecretKey) keystore.getKey("csvkey", password);
			return key;
		}catch(Exception e){

			e.printStackTrace();
		}
		return null;

	}

	public static void GenKey() throws Exception{
		
		KeyGenerator cs = KeyGenerator.getInstance("AES");
		SecretKey myKey = cs.generateKey();
		storeKey(myKey);
	} 

	public static Cipher getCipher() throws Exception{

		Cipher algo = Cipher.getInstance("AES");
		return algo;
	
	}


}
		
		