package bin;

class EnquireBuilderFactory{

	static Enquire enqEmp = new EnquireEmp();
	static Enquire enqCon = new EnquireCon();

	public static Enquire getInstance(int i){

		if(i == 1 || i == 2){
			
			return enqEmp;
		}else{

			return enqCon;
		}
	}
}