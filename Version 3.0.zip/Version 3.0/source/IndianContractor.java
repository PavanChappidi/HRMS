package bin;

class IndianContractor extends Contractor{
	private String NAME;
	public final String TYPE = "contractor";
	private String EMPID;
	private String PAY;
	private String MANAGER;
	private String CONTACT;
	private String ADDRESS;
	private final String COUNTRY = "INDIA";
	private String STATUS = "ACTIVE";
	private String DOJ;
	private String DOE;
	private String EMAIL;
	private String DESIGNATION;
	private String DEPARTMENT;
	
	public String getEmpID()throws Exception{
	
		return IDGenerator.generateConID(this.COUNTRY);
	}


	public String getName(){

		return this.NAME;
	}

	public String getCTC(){
		
		return this.PAY;
	}
	
	public String getManager(){

		return this.MANAGER;
	}

	public String getContact(){

		return this.CONTACT;
	}
	public String getAddress(){

		return this.ADDRESS;
	}

	public  String getStatus(){

		return this.STATUS;
	}
	public String getCountry(){
		
		return this.COUNTRY;
	}
	
	public String getAll(){

		return null;
	}
	public void setEmpID(String id){

		this.EMPID = id;
	}
	
	public void setName(String name){
		
		this.NAME = name;
	}
	
	public void setCTC(String ctc){
		
		this.PAY = ctc;
	}

	public void setManager(String manager){
		
		this.MANAGER = manager;
	}

	public void setAddr(String address){
		
		 this.ADDRESS = address;
	
	}

	public void setContact(String contact){
		
		this.CONTACT = contact;
		
	}

	public void setDOJ(String date){
			
		this.DOJ = date;
	}

	public void setDOE(String doe){
			
		this.DOE = doe;
	}

	public void setDesignation(String des){
			
		this.DESIGNATION = des;
	}

	public void setDepartment(String dept){
			
		this.DEPARTMENT = dept;
	}
	public void setEmail(String mail){
			
		this.EMAIL = mail;
	}
}
	 