package bin;

import java.time.LocalDate;

public class DateChecker{

	public static int[] fieldSeparator(String strdate){
		
		String[] fields = strdate.split("-");
		int[] date = new int[3];
		date[0] = Integer.parseInt(fields[2]);
		date[1] = Integer.parseInt(fields[1]);
		date[2] = Integer.parseInt(fields[0]);
		return date;  
	}

	public static boolean checkDate(String strdate){
		
		boolean flag = false;
		try{
			int[] date = fieldSeparator(strdate);
			LocalDate sample = LocalDate.of(date[0],date[1],date[2]);
			int len = sample.lengthOfMonth();
			if(len >= date[1] && date[0] == 2019){
			
				flag = true;
			}
		}catch(Exception e){
		
			System.out.print("Invalid Date");
		}
		return flag;

	}

	public static boolean checkPeriod(String DOJ,String DOE){

		int[] fields1 = fieldSeparator(DOJ);
		int[] fields2 = fieldSeparator(DOE);
		LocalDate joining = LocalDate.of(fields1[0],fields1[1],fields1[2]);
		LocalDate ending = LocalDate.of(fields2[0],fields2[1],fields2[2]);
		if(ending.isAfter(joining)){
			return true;
		}else{
			return false;
		}
	}
}
