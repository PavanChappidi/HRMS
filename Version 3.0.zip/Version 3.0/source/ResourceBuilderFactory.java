package bin;

class ResourceBuilderFactory{


		
		static Resource indianEmp = new IndianEmployee();
		static Resource usEmp = new USEmployee();
		static Resource indianCon = new  IndianContractor();
		static Resource usCon = new USContractor();
	public static Resource getInstance(int i){

		switch(i){

			case 1: return indianEmp;
				
			case 2: return  usEmp;
				
			case 3: return  indianCon;
				
			case 4: return usCon;
				
			default: System.out.print("please enter valid option");
				break;
		}
		return null;
	}
}

		