package bin;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.StringReader;
import java.io.File;
class StringModifier{

	static String comStr = "hey there";
	static byte[] tt;
	static File database = new File(".\\enhdb.csv");
	static SecuringData cd = new SecuringData();
	public static void modifyStr(String empID,String newEntry, int loc )throws Exception{

		boolean flag = true;
		String dec = decryptStream();
		BufferedReader filereader = new BufferedReader(new StringReader(dec));
		String modifiedStr = filereader.readLine();
		String cache;
		while((cache = filereader.readLine())!= null){
			if(cache.contains(empID)){
				String[] modify = cache.split(",");
				if(!modify[loc].equals(newEntry.toUpperCase())){
				modify[loc] = newEntry.toUpperCase();
				}else{

					System.out.print("\n no change required");
					flag = false;
					
				}
				String temp="";
				for(int i=0 ; i< modify.length ; i++){
					if(i==0){

						temp = temp+modify[i];
					}else{
					temp = temp+","+modify[i];
					}
				}
				modifiedStr = modifiedStr + "\n"+temp;
				
			}else{

				modifiedStr =modifiedStr+"\n"+cache;
				
			}
		}
		writeEncrypted(modifiedStr);
		if(flag){
		System.out.print("\n Entry Modified Successfully \n");
		}
		
	}


	public static void writeEncrypted(String decTemp) throws Exception {

	FileOutputStream fos = new FileOutputStream(database);
	tt = cd.encryptData(decTemp.getBytes());
	fos.write(tt);
	fos.flush();
	fos.close();
	System.out.print("\n Data encrypted and uploaded to csv");

	}


	public static String decryptStream(){

		String allData="no entry sent";
		try{
			FileInputStream fis1 = new FileInputStream(database);
			byte[] decStr = new byte[(int) database.length()];
			fis1.read(decStr);
			allData = new String(cd.decryptData(decStr));
		}catch(Exception e){
			System.out.print("\n exception at decryptStream");
		}
		return allData;
	}


}