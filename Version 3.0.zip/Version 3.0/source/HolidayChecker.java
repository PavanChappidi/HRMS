package bin;

import java.net.URL;
import java.net.HttpURLConnection;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.time.LocalDate;
import java.time.DayOfWeek;

class HolidayChecker{
	
	static String Date;
	static String Country;
	static int weekend;
	static String requestURL;
static final String apiKey="key=8d11b928-21b6-4bab-9089-2d4ce155f885";
	public static String getURL(){
		try{
		String[] indFields = Date.split("-");
		LocalDate sun = LocalDate.of(Integer.parseInt(indFields[2]),Integer.parseInt(indFields[1]),Integer.parseInt(indFields[0]));
		weekend = getDayNumber(sun);
		String holidayapi = "https://holidayapi.com/v1/holidays?pretty&"+apiKey;
		requestURL = holidayapi+"&"+"country="+Country+"&"+"year="+indFields[2]+"&"+"month="+indFields[1]+"&"+"day="+indFields[0];
		
		}catch(ArrayIndexOutOfBoundsException e){
			System.out.print("\nPlease enter valid date format");
		}
		return requestURL;	
	}

	public static boolean getResponse(String date, String country) throws Exception{
		if(country.equalsIgnoreCase("india")){
			Country = "IN";	
		}else{
			Country = "US";
		}
		Date = date;
		
		boolean flag = false;	
		String responseJSON = "JSON Response in String";	
		URL apiURL = new URL(getURL());
		HttpURLConnection requestAPI = (HttpURLConnection) apiURL.openConnection();
		requestAPI.setRequestMethod("GET");
		requestAPI.connect();
		int resCode = requestAPI.getResponseCode();
		if(resCode == 200){
		
			InputStreamReader resStream = new InputStreamReader(apiURL.openStream());
			BufferedReader responseReader = new BufferedReader(resStream);
			String temp;
			
			while((temp = responseReader.readLine()) != null){
			
				if(temp.contains("true") || (weekend == 6 || weekend == 7)){
					
					flag = true;	
					System.out.print("\n it is a holiday");
					break;
					
				}
	
			}	
		}

		return flag;
	} 

	public static int getDayNumber(LocalDate date) {
    		DayOfWeek day = date.getDayOfWeek();
   		 return day.getValue();
	}




}