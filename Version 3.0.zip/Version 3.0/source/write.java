package bin;
import java.util.HashMap;
import java.io.IOException;
class write{
	static write emp = new write();
	private static String temp = "";
	HashMap<Integer,String> db = new HashMap<Integer, String>();
	static CSVOperation enh = new CSVOperation();
	public void readInput(Resource in, Enquire enq) throws Exception{
		
		
		enq.askForInputs(in);
		db = enq.getAskedData();
	}

	public void writeToDB()throws Exception{
		enh.addFile(db);
		sendConfirmation(db);
	}
	public void sendConfirmation(HashMap<Integer,String> singleRecord)throws Exception{
	
		MailClient.sendNotification(Peek.getContentInMap(singleRecord),getMangerMailID(singleRecord.get(7)));		
	}
	public static write getInstance(){
	
		return emp;
	}

	public static String getMangerMailID(String EmpID)throws Exception{
	
		HashMap<Integer,String> managerDetails = enh.getSingleRecord(EmpID);
		return managerDetails.get(10);
	}
}		

 
	

		