package bin;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;  
import java.util.Date; 
class Modify{
	BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
	CSVOperation toModify = new CSVOperation();
	public void menu() throws Exception{

		int choice = 2;
		String newStr;
		String EmpID;
		System.out.print("\t\t\t\t Modify Options\n");
		System.out.print("\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		System.out.print("\t\t\t\tPlease enter target Employee ID:");
		while(!(toModify.validateEmpID((EmpID = consoleReader.readLine().toUpperCase())))){
			System.out.print("\nthere is no employee with that ID please check your entry and enter again : ");	
		}
		System.out.print("\t\t\t\t 1.Name \n\t\t\t\t 2.CTC \t\t\t\t  \n \t\t\t\t 3.Address \n \t\t\t\t 4.Phone\n\n");
		System.out.print("\t\t\t\t Choose which attribute you would like to modify [eg:2] : ");
		choice = Integer.parseInt(consoleReader.readLine());
		switch(choice){


			case 1:	
					System.out.print("Please enter new entry : ");
					while(!(newStr = consoleReader.readLine()).matches("[A-Za-z ]{4,40}")){
						
						System.out.print("\n name should contain alphabets only, Please Enter again : ");
					}
					toModify.modifyQuery(EmpID, newStr, 1);
					break;

			case 2:		
					System.out.print("Please enter new entry : ");
					while(!(newStr = consoleReader.readLine()).matches("[0-9]{5,8}")){
						
						System.out.print("\n CTC should contain numbers only, Please Enter again : ");
					}
					toModify.modifyQuery(EmpID, newStr, 3);
					break;

			
			case 3:		System.out.print("Please enter new entry : ");
					while(!(newStr = consoleReader.readLine()).matches("[0-9A-Za-z/#. ]{4,70}")){
						
						System.out.print("\n Address cannot contain comma, Please Enter again : ");
					}
					toModify.modifyQuery(EmpID, newStr, 8);
					break;	
		
			case 4:		System.out.print("Please enter new entry : ");
					while(!(newStr = consoleReader.readLine()).matches("[6-9]{1}[0-9]{9}")){
						
						System.out.print("\n Phone number should contain 10 digits and should be starting 6,7,8,9  , Please Enter again : ");
					}
					toModify.modifyQuery(EmpID, newStr, 9);
					break;	
			
			default:	System.out.print("\n please enter valid option and try again\n\n");
					break;						

		}
	}

	public void remove() throws Exception{
			
			String EmpID;
			System.out.print("Please enter target employee ID to be removed : ");
			while(!(toModify.validateEmpID((EmpID = consoleReader.readLine().toUpperCase())))){
				System.out.print("\nthere is no employee with that ID please check your entry and enter again : ");	
			}
			
			
			toModify.modifyQuery(EmpID,"TERMINATED", 12);
			SimpleDateFormat defFormat = new SimpleDateFormat("dd-MM-yyyy");
			Date date = new Date(); 
			String currentDate = defFormat.format(date);
			toModify.modifyQuery(EmpID,currentDate, 6);
			System.out.print("\nEmployee with Employee ID "+ EmpID + "  is terminated" );
	}
			
}				