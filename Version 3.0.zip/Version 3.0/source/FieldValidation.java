package bin;
import java.util.regex.Pattern;
import java.util.HashMap;
class FieldValidation{


	static String namePattern = "[A-Za-z ]{4,40}";
	static String mobilePattern = "[6-9]{1}[0-9]{9}";
	static String addressPattern = "[0-9A-Za-z/#. ]{4,70}";
	static String CTCPattern = "[0-9]{5,8}";

	public static boolean checkName(String anyStr){
	
		return Pattern.matches(namePattern, anyStr);
	}

	public static boolean checkContact(String number){

		return Pattern.matches(mobilePattern, number);
	}

	public static boolean checkAddress(String addr){

		return Pattern.matches(addressPattern, addr);
	}
	
	public static boolean checkCTC(String ctc){

		return Pattern.matches(CTCPattern, ctc);
	}

	public static boolean checkDate(String date,String country) throws Exception{
			if(date.matches("[0-9]{1,2}(-)[0-9]{1,2}(-)[0-9]{4}") && DateChecker.checkDate(date)){
				return HolidayChecker.getResponse(date,country);
			}else{
				return true;
			}
	}

	public static boolean checkPeriod(String DOJ, String DOE,String Country) throws Exception{

			if(!checkDate(DOE,Country)){
	
				return DateChecker.checkPeriod(DOJ,DOE);
			}else{

				return false;
			}
	}

	public static boolean validateManagerID(String EmpID) throws Exception{
		boolean flag = false;
		CSVOperation val = new CSVOperation();
		if(val.validateEmpID(EmpID)){
			if(EmpID.substring(4,7).equalsIgnoreCase("EMP")){
					
				flag = true;
			}					
		}
		return flag;
	}

	
}
	

			

	