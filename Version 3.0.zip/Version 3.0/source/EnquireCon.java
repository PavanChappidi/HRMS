package bin;
import java.util.HashMap;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

class EnquireCon implements Enquire{
		static String temp = null;
		BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
		HashMap<Integer,String> cache = new HashMap<Integer,String>();
		int i = 0;
		String fname,lname;
	public void askForInputs(Resource user1) throws Exception{
		temp = user1.getEmpID().toUpperCase();
		System.out.print("Contractor ID generated " + temp+ "\n");
		user1.setEmpID(temp);
		cache.put(i++,temp);
		System.out.print("\nEnter First Name Of the Contractor : ");
		while(!FieldValidation.checkName(fname = consoleReader.readLine())){

			System.out.print("\n name cannot contain number or special characters, Please enter again : ");
		}
		
		System.out.print("\nEnter Lasr Name Of the Contractor : ");
		while(!FieldValidation.checkName(lname = consoleReader.readLine())){

			System.out.print("\n name cannot contain number or special characters, Please enter again : ");
		}
		temp = fname + lname;
		user1.setName(temp);
		cache.put(i++,temp);
		System.out.print("\nEnter Department Of the Contractor : ");
		while(!FieldValidation.checkName(temp = consoleReader.readLine())){

			System.out.print("\n name cannot contain number or special characters, Please enter again : ");
		}
		user1.setDepartment(temp);
		cache.put(i++,temp);
		System.out.print("\nEnter Designation Of the Contractor : ");
		while(!FieldValidation.checkName(temp = consoleReader.readLine())){

			System.out.print("\n name cannot contain number or special characters, Please enter again : ");
		}
		user1.setDesignation(temp);
		cache.put(i++,temp);
		System.out.print("\n Enter Pay: ");
		while(!FieldValidation.checkCTC(temp = consoleReader.readLine())){

			System.out.print("\n CTC should contain numbers, Please enter again : ");
		}
		user1.setCTC(temp);
		cache.put(i++,temp);
		System.out.print("\nEnter Date of Joining  Of the Contractor(dd-mm-yyyy) : ");
		while(FieldValidation.checkDate(temp = consoleReader.readLine(),user1.getCountry())){
			System.out.print("\n Please enter valid date, Please enter again : ");
		}
		user1.setDOJ(temp);
		cache.put(i++, temp);
		String join = temp;
		System.out.print("\nEnter Date of Ending  Of the Contractor(dd-mm-yyyy) : ");
		while(!FieldValidation.checkPeriod(join,consoleReader.readLine(),user1.getCountry())){

			System.out.print("\n ending date should be after joining date or enter date, Please enter again : ");
			
		}
		user1.setDOE(temp);
		cache.put(i++, temp);
		System.out.print("\nEnter Manager ID Of the Contractor : ");
		while(!FieldValidation.validateManagerID(temp = consoleReader.readLine())){

			System.out.print("\n name cannot contain number or special characters, Please enter again : ");
		}
		user1.setManager(temp);
		cache.put(i++, temp);
		System.out.print("\nEnter address for communication  Of the Contractor : ");		
		while(!FieldValidation.checkAddress(temp = consoleReader.readLine())){

			System.out.print("\n name cannot contain number or special characters, Please enter again : ");
		}
		user1.setAddr(temp);
		cache.put(i++, temp);
		System.out.print("\nEnter Phone number for communication  Of the Contractor : ");	
		while(!FieldValidation.checkContact(temp = consoleReader.readLine())){

			System.out.print("\n name cannot contain number or special characters, Please enter again : ");
		}
		user1.setContact(temp);
		cache.put(i++, temp);
		System.out.print("\nEnter Email ID for communication  Of the Contractor : ");
		while(FieldValidation.checkName(temp = consoleReader.readLine())){

			System.out.print("\n name cannot contain number or special characters, Please enter again : ");
		}
		user1.setEmail(temp);
		cache.put(i++, temp);
		cache.put(i++,user1.getCountry());
		cache.put(i++,user1.getStatus());

		
					
	}

	public  HashMap getAskedData(){
			i=0;
			return cache;
	}
} 	