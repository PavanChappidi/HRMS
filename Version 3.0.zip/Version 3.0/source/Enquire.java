package bin;
import java.util.List;
import java.util.HashMap;
import java.io.IOException;
interface Enquire{

	public void askForInputs(Resource obj) throws Exception;
	public HashMap getAskedData();
}