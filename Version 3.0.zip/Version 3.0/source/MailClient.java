package bin;

import java.util.Properties;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.InternetAddress;
import javax.mail.Message;
import javax.mail.Transport;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.activation.*;

public class MailClient{

	public static void sendNotification(String Content, String managerMail){
		try{
		Properties defProperties = new Properties();
		defProperties.put("mail.smtp.auth","true");
		defProperties.put("mail.smtp.starttls.enable","true");
		defProperties.put("mail.smtp.host","smtp.gmail.com");
		defProperties.put("mail.smtp.port","587");
		Session pushNotification = Session.getInstance((defProperties), 
			new Authenticator(){

				protected PasswordAuthentication getPasswordAuthentication() { 
                                         
                			return new PasswordAuthentication("pavanchappidik@gmail.com","$Pav_1011$"); 
           			 } 
          		});
		MimeMessage notification = new MimeMessage(pushNotification);
		notification.setFrom(new InternetAddress("pavanchappidik@gmail.com"));
		notification.setRecipients(Message.RecipientType.TO, InternetAddress.parse(managerMail));
		notification.setSubject("New Employee Creation alert");
		notification.setText(Content);
		Transport.send(notification);
		System.out.print("\n mail sent successfully");
		}catch(Exception e){
				e.printStackTrace();
		}

	}



}