package bin;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.HashMap;
class Driver{
	
	static BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
	static Modify mod = new Modify();
	public static void main(String[] args){
		int i = 1;
		boolean flag = true;
		while(flag){
			System.out.print("\n\t\t\t\tOperation Terminal\n");
			System.out.print("\t\t~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
			System.out.print("\n\n\t\t\t\t 1.Write \n\t\t\t\t 2.Peek \t\t\t\t  \n \t\t\t\t 3.Modify\n \t\t\t\t 4.remove\n\t\t\t\t 5.exit\n\n");
			System.out.print("\t\t\t\t Enter any option [eg:2] : ");
			try{
			i = Integer.parseInt(consoleReader.readLine());
			write add = write.getInstance();
			Peek search = new Peek();
			switch(i){
		
				case 1 :	System.out.print("\n\n\t\t\t\t 1.Indian Employee\n \t\t\t\t 2.USEmployee \n\t\t\t\t 3.IndianContractor \n\t\t\t\t 4.USContractor\n\n");
						System.out.print("\t\t\t Choose One Option [eg:1] : ");
						int option = Integer.parseInt(consoleReader.readLine());
						Resource mainInstance = ResourceBuilderFactory.getInstance(option);
						Enquire enqInstance = EnquireBuilderFactory.getInstance(option);
						add.readInput(mainInstance, enqInstance);
						add.writeToDB();
						break;

				case 2 :	search.menu();
						break;

				case 3 :	mod.menu();
						break;

				case 4 : 	mod.remove();
						break;

				case 5 :	flag = false;
						break;
				default :	System.out.print("\nPlease choose from the above options only");
						break;
			
			}
			
			}catch(Exception e){

			System.out.print("\nplease enter desired option and try again");
			e.printStackTrace();
		}
		}
		
	}
}