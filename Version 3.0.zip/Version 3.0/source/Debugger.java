package bin;
import java.io.IOException;
import java.util.HashMap;
class Debugger{

	public static void main(String[] args) throws IOException{

		Peek test = new Peek();
		test.menu();
	}
}