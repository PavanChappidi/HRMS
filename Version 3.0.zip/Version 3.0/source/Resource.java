package bin;

interface Resource{

	public String getEmpID() throws Exception;
	public String getName();
	public String getCTC();
	public String getManager();
	public String getAddress();
	public String getContact();
	public String getStatus();
	public String getCountry();
	public String getAll();
	public void setEmpID(String id);
	public void setName(String name);
	public void setCTC(String ctc);
	public void setManager(String manager);
	public void setAddr(String address);
	public void setContact(String contact);
	public void setDOJ(String date);
	public void setDOE(String date);
	public void setDepartment(String dept);
	public void setDesignation(String desgn);
	public void setEmail(String mail);
}