package bin;

class USEmployee extends Employee{

	private String NAME;
	public final String TYPE = "employee";
	private String EMPID;
	private String CTC;
	private String MANAGER="ISINEMP1001";
	private String CONTACT;
	private String ADDRESS;
	public final String COUNTRY = "US";
	private String STATUS = "ACTIVE";
	private String DOJ;
	private String EMAIL;
	private String DESIGNATION;
	private String DEPARTMENT;
	public String getEmpID() throws Exception{
	
		return IDGenerator.generateEmpID(this.COUNTRY);
	}


	public String getName(){

		return this.NAME;
	}

	public String getCTC(){
		
		return this.CTC;
	}
	
	public String getManager(){

		return this.MANAGER;
	}

	public String getContact(){

		return this.CONTACT;
	}
	public String getAddress(){

		return this.ADDRESS;
	}

	public  String getStatus(){

		return this.STATUS;
	}

	public String getCountry(){

		return this.COUNTRY;
	}
	
	public String getAll(){

		return null;
	}
	public void setEmpID(String id){

		this.EMPID = id;
	}
	
	public void setName(String name){
		
		this.NAME = name;
	}
	
	public void setCTC(String ctc){
		
		this.CTC = ctc;
	}

	public void setManager(String manager){
		
		this.MANAGER = manager;
	}

	public void setAddr(String address){
		
		this.ADDRESS = address;
	}

	public void setContact(String contact){
		
		this.CONTACT = contact;
			
	}

	public void setDOJ(String date){
			
		this.DOJ = date;
	}

	public void setDOE(String status){
			
		System.out.print("Alert: Employee cannot have Date of ending");
	}

	public void setDesignation(String des){
			
		this.DESIGNATION = des;
	}

	public void setDepartment(String dept){
			
		this.DEPARTMENT = dept;
	}
	public void setEmail(String mail){
			
		this.EMAIL = mail;
	}
	
}
	 