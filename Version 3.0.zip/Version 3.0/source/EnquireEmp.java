package bin;
import java.util.HashMap;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

class EnquireEmp implements Enquire{

		static String temp;
		boolean flag = false;
		BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));
		HashMap<Integer,String> cache = new HashMap<Integer,String>();
		int i = 0;
		String fname,lname;
	public void askForInputs(Resource user1) throws Exception{
		temp = user1.getEmpID().toUpperCase();
		System.out.print("Employee ID generated " + temp + "\n");
		user1.setEmpID(temp);
		cache.put(i++,temp);
		System.out.print("\nEnter First Name Of the Employee : ");
		while(!FieldValidation.checkName(fname = consoleReader.readLine())){

			System.out.print("\n name cannot contain number or special characters, Please enter again : ");
		}
		
		System.out.print("\nEnter Last Name Of the Employee : ");
		while(!FieldValidation.checkName(lname = consoleReader.readLine())){

			System.out.print("\n name cannot contain number or special characters, Please enter again : ");
		}
		temp = fname +" "+lname;
		user1.setName(temp);
		cache.put(i++,temp);
		System.out.print("\nEnter Department Of the Employee : ");
		while(!FieldValidation.checkName(temp = consoleReader.readLine())){

			System.out.print("\n name cannot contain number or special characters, Please enter again : ");
		}
		user1.setDepartment(temp);
		cache.put(i++,temp);
		System.out.print("\nEnter Designation Of the Employee : ");
		while(!FieldValidation.checkName(temp = consoleReader.readLine())){

			System.out.print("\n name cannot contain number or special characters, Please enter again : ");
		}
		user1.setDesignation(temp);
		cache.put(i++,temp);
		System.out.print("\nEnter CTC or Pay : ");
		while(!FieldValidation.checkCTC(temp = consoleReader.readLine())){

			System.out.print("\n CTC should contain numbers, Please enter again : ");
		}
		user1.setCTC(temp);
		cache.put(i++,temp);
		System.out.print("\nEnter Date of Joining  Of the Contractor(dd-mm-yyyy) : ");
		while(FieldValidation.checkDate(temp = consoleReader.readLine(),user1.getCountry())){
			System.out.print("\n Please enter valid date, Please enter again : ");
		}
		user1.setDOJ(temp);
		cache.put(i++, temp);
		cache.put(i++, "NIL");
		temp = "NIL";
		System.out.print("\n Employee has manager, if yes press enter  or type No:  ");
		boolean decision = consoleReader.readLine().equalsIgnoreCase("No") ? false : true;
		if(decision){  
		System.out.print("\nEnter Manager ID Of the Employee : ");
			while(!FieldValidation.validateManagerID(temp = consoleReader.readLine())){

				System.out.print("\n No manager exists under this employee ID, Please enter again : ");
			}
		user1.setManager(temp);
		cache.put(i++, temp);
		}else{
		cache.put(i++, user1.getManager());
		
		}
		System.out.print("\nEnter address for communication  Of the Employee : ");		
		while(!FieldValidation.checkAddress(temp = consoleReader.readLine())){

			System.out.print("\n length doesnt match  please enter within 70 characters, Please enter again : ");
		}
		user1.setAddr(temp);
		cache.put(i++, temp);
		System.out.print("\nEnter Phone number for communication  Of the Employee : ");	
		while(!FieldValidation.checkContact(temp = consoleReader.readLine())){

			System.out.print("\n name cannot contain number or special characters, Please enter again : ");
		}
		user1.setContact(temp);
		cache.put(i++, temp);
		System.out.print("\nEnter Email ID for communication  Of the Employee : ");
		while(FieldValidation.checkName(temp = consoleReader.readLine())){

			System.out.print("\n name cannot contain number or special characters, Please enter again : ");
		}
		user1.setEmail(temp);
		cache.put(i++, temp);
		cache.put(i++,user1.getCountry());
		cache.put(i++,user1.getStatus());
					
	}

	public  HashMap getAskedData(){
			i=0;
			return cache;
	}
} 	